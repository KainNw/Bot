# Cambio solicitado: «Ataque inmediato»

**Estado: requisitos documentados; implementación y pruebas de aplicación pendientes.**

## Objetivo

Revisar por qué el bot tarda en atacar cuando el panel tiene configurados
**0 segundos**. Usar Auto Battle como referencia para identificar la llamada
nativa y separar la espera que introduce el bot de la demora de la función
invocada o de la respuesta del juego.

No se ha podido inspeccionar ninguna función de ataque: el repositorio
solo contiene `README.md`. No está confirmado que el bot use una orden
distinta de Auto Battle ni se ha identificado la causa de la demora.

## Opción en el panel

Añadir una casilla con el nombre **«Ataque inmediato»**, que pueda activarse
y desactivarse. El valor inicial propuesto es desactivado para conservar el
modo actual hasta que el usuario lo active.

| Opción | Espera configurada | Comportamiento solicitado |
| --- | --- | --- |
| Desactivada | Cualquier valor admitido | Conservar el comportamiento actual. |
| Activada | 0 segundos | Omitir la espera configurada antes de enviar el ataque. |
| Activada | Mayor que 0 | Propuesta: respetar el tiempo configurado; este caso no quedó definido expresamente. |

«0 segundos» significa que esta opción no añade una espera configurada.
La latencia propia del juego, la comunicación o la función de ataque debe
medirse por separado; no se puede prometer una respuesta instantánea.

La forma de guardar la casilla se adaptará al mecanismo que ya use el panel,
cuando ese código esté disponible. El comportamiento con valores inválidos
debe respetar las validaciones existentes.

## Revisión técnica pendiente

1. Localizar el código de Auto Battle y su llamada de ataque nativa.
2. Seguir la ruta del panel hasta el envío del ataque del bot: lectura del
   tiempo, conversión de unidades, temporizadores, colas y función invocada.
3. Medir por separado el tiempo desde la solicitud hasta el envío, la entrada
   en la función de ataque y la respuesta, usando un reloj monotónico cuando
   el entorno de ejecución lo permita. No registrar credenciales.
4. Identificar si la demora se añade antes del envío o dentro de la función.
5. Integrar la casilla con el flujo existente y omitir la espera configurada
   en el caso activado con 0 segundos, sin generar envíos duplicados.
6. Validar con las pruebas y el entorno de ejecución reales del proyecto.

No se propone una función, orden o protocolo concretos sin haberlos visto
en el código.

## Validación que debe realizarse con el código

- Casilla desactivada: verificar que conserva el comportamiento anterior.
- Casilla activada y tiempo 0: comprobar que no programa la espera configurada
  y envía un único ataque al alcanzar el punto de envío.
- Revisar valores mayores que 0 según el comportamiento definitivo elegido.
- Cambiar el estado de la casilla y comprobar que el siguiente ataque utiliza
  el estado correcto, respetando la gestión de tareas pendientes del bot.
- Comparar con Auto Battle y separar la demora previa al envío de la demora
  interna o remota. Registrar resultados medidos, sin afirmar equivalencia
  si las rutas son diferentes.
- Ejecutar las comprobaciones de compilación, tipos y pruebas que el proyecto
  ya requiera. Una revisión sintáctica no sustituye la validación funcional.

**Ninguna de estas pruebas de aplicación se ha ejecutado.**

## Material necesario para implementar

El archivo principal del bot; el panel y su configuración; las funciones de
Auto Battle y de ataque; el código de temporización; los manifiestos y archivos
de bloqueo de dependencias; las instrucciones y pruebas existentes.
Si están distribuidos en varios archivos, facilitar el proyecto completo o
el repositorio y la rama exactos, sin incluir secretos.
