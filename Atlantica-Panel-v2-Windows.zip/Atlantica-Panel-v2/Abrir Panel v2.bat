@echo off
setlocal
cd /d "%~dp0"
where py.exe >nul 2>&1
if errorlevel 1 (
    python -I "panel_v2.py"
) else (
    py -3 -I "panel_v2.py"
)
if errorlevel 1 (
    echo.
    echo Revisa el mensaje anterior. El panel requiere Python 3.11 o posterior con Tcl/Tk.
    pause
)
