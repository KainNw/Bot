"""Launch Panel v2 from a checkout."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

from atlantica_bot.panel_v2 import main  # noqa: E402

if __name__ == "__main__":
    raise SystemExit(main())
