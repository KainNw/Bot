"""Desktop view of the client file and existing character settings."""

from __future__ import annotations

import json
import sys
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, ttk

from .character_profiles import CharacterPreferences
from .client_window import ClientWindow
from .errors import DiagnosticError
from .panel_v2 import (
    ClientFile,
    inspect_client_file,
    inspect_window,
    make_report,
    read_reference_sha256,
)
from .profiles import BotProfile, ProfileStore
from .report import save_report
from .saved_profiles_view import open_saved_profiles
from .ui_theme import apply_theme, card
from .windows import WindowsSystem


class PanelV2:
    def __init__(self, root: tk.Tk, system: WindowsSystem | None) -> None:
        self.root = root
        self.system = system
        self.windows: dict[str, ClientWindow] = {}
        self.client: ClientFile | None = None
        self.window_state: dict | None = None
        self.reference: str | None = None
        self.selected_profile: tuple[BotProfile, CharacterPreferences] | None = None
        self.window_choice = tk.StringVar(root)
        self.profile_label = tk.StringVar(root, value="Elige un perfil guardado.")
        self.status = tk.StringVar(root, value="Elige Atlantica.exe para identificar el cliente.")
        self.fields = {
            field: tk.StringVar(root, value="—")
            for field in (
                "Archivo",
                "Versión",
                "Arquitectura",
                "Tamaño",
                "Imagen PE",
                "SHA-256",
                "Comparación",
            )
        }

        apply_theme(root)
        root.title("Atlantica · Panel v2")
        root.minsize(750, 410)
        shell = ttk.Frame(root, style="Page.TFrame", padding=22)
        shell.pack(fill="both", expand=True)
        header = ttk.Frame(shell, style="Page.TFrame")
        header.pack(fill="x", pady=(0, 16))
        ttk.Label(header, text="Atlantica · Panel v2", style="Title.TLabel").pack(side="left")
        ttk.Button(header, text="Elegir perfil guardado", command=self.show_profiles).pack(
            side="right"
        )

        report_card, body = card(shell, "Compilación del cliente")
        report_card.pack(fill="both", expand=True)
        if system is not None:
            windows_row = ttk.Frame(body)
            windows_row.pack(fill="x", pady=(0, 8))
            self.window_list = ttk.Combobox(
                windows_row, textvariable=self.window_choice, state="readonly"
            )
            self.window_list.pack(side="left", fill="x", expand=True)
            ttk.Button(windows_row, text="Actualizar lista", command=self.refresh_windows).pack(
                side="left", padx=8
            )
            self.analyze_window_button = ttk.Button(
                windows_row, text="Analizar ventana", command=self.analyze_window, state="disabled"
            )
            self.analyze_window_button.pack(side="left")
            self.copy_state_button = ttk.Button(
                windows_row, text="Copiar estado PID", command=self.copy_state, state="disabled"
            )
            self.copy_state_button.pack(side="left", padx=(8, 0))
            self.window_choice.trace_add("write", self.update_window_selection)
            root.after_idle(self.refresh_windows)

        ttk.Label(body, textvariable=self.profile_label, style="Caption.TLabel").pack(
            anchor="w", pady=(0, 8)
        )
        actions = ttk.Frame(body)
        actions.pack(fill="x", pady=(0, 12))
        ttk.Button(actions, text="Abrir ejecutable", command=self.choose_file).pack(side="left")
        ttk.Button(actions, text="Comparar informe", command=self.choose_reference).pack(
            side="left", padx=8
        )
        self.save_button = ttk.Button(
            actions, text="Guardar informe", command=self.export_report, state="disabled"
        )
        self.save_button.pack(side="left")

        details = ttk.Frame(body)
        details.pack(fill="x")
        details.columnconfigure(1, weight=1)
        for index, (label, value) in enumerate(self.fields.items()):
            ttk.Label(details, text=label, style="Caption.TLabel").grid(
                row=index, column=0, sticky="w", padx=(0, 14), pady=3
            )
            if label == "SHA-256":
                widget = ttk.Entry(details, textvariable=value, state="readonly", width=66)
            else:
                widget = ttk.Label(details, textvariable=value)
            widget.grid(row=index, column=1, sticky="ew", pady=3)
        ttk.Label(body, textvariable=self.status, style="Muted.TLabel", wraplength=700).pack(
            anchor="w", pady=(12, 0)
        )

    def refresh_windows(self) -> None:
        if self.system is None:
            return
        try:
            windows = self.system.game_windows()
        except (DiagnosticError, OSError) as exc:
            self.status.set(str(exc))
            return
        self.windows = {window.label: window for window in windows}
        self.window_list.configure(values=tuple(self.windows))
        if self.window_choice.get() not in self.windows:
            self.window_choice.set(next(iter(self.windows), ""))
        self.update_window_selection()
        if not self.windows:
            self.status.set("Abre Atlantica y actualiza la lista, o elige el ejecutable.")

    def update_window_selection(self, *_) -> None:
        selected = self.windows.get(self.window_choice.get())
        state = "normal" if selected is not None else "disabled"
        self.analyze_window_button.configure(state=state)
        self.copy_state_button.configure(
            text=f"Copiar estado PID {selected.pid}" if selected else "Copiar estado PID",
            state=state,
        )
        if self.window_state is not None and (
            selected is None
            or selected.pid != self.window_state["process"]["pid"]
            or selected.handle != self.window_state["window"]["handle"]
            or selected.thread_id != self.window_state["window"]["thread_id"]
        ):
            self.client = None
            self.window_state = None
            self.render_report()
            self.status.set("Analiza la ventana elegida para actualizar el diagnóstico.")

    def analyze_window(self) -> None:
        if self.system is None:
            return
        selected = self.windows.get(self.window_choice.get())
        if selected is None:
            return
        self.client = None
        self.window_state = None
        try:
            self.client, self.window_state = inspect_window(self.system, selected)
            verified = self.window_state["memory_read"]["status"] == "verified"
            header = "cabecera PE verificada" if verified else "cabecera PE pendiente de verificar"
            self.status.set(f"PID {selected.pid} · {header}.")
        except (DiagnosticError, OSError) as exc:
            self.status.set(str(exc))
        self.render_report()

    def choose_file(self) -> None:
        filename = filedialog.askopenfilename(
            parent=self.root,
            title="Elegir el ejecutable",
            filetypes=[("Ejecutable de Windows", "*.exe")],
        )
        if not filename:
            return
        self.client = None
        self.window_state = None
        try:
            self.client = inspect_client_file(Path(filename))
            self.status.set("Análisis del ejecutable completado.")
        except (DiagnosticError, OSError) as exc:
            self.status.set(str(exc))
        self.render_report()

    def choose_reference(self) -> None:
        filename = filedialog.askopenfilename(
            parent=self.root,
            title="Elegir un informe anterior",
            filetypes=[("Informe JSON", "*.json")],
        )
        if not filename:
            return
        self.reference = None
        try:
            self.reference = read_reference_sha256(Path(filename))
            self.status.set(f"Informe de referencia cargado · {Path(filename).name}")
        except (DiagnosticError, OSError) as exc:
            self.status.set(str(exc))
        self.render_report()

    def render_report(self) -> None:
        client = self.client
        self.save_button.configure(state="normal" if client else "disabled")
        if client is None:
            for field in self.fields.values():
                field.set("—")
            return
        self.fields["Archivo"].set(client.name)
        self.fields["Versión"].set(client.file_version or "Sin versión en recursos")
        self.fields["Arquitectura"].set(f"{client.architecture} · {client.bits} bits")
        self.fields["Tamaño"].set(f"{client.size_bytes:,} bytes")
        self.fields["Imagen PE"].set(f"{client.image_size:,} bytes · {client.sections} secciones")
        self.fields["SHA-256"].set(client.sha256)
        comparison = "Elige un informe para comparar"
        if self.reference is not None:
            comparison = (
                "Coincide con el informe"
                if client.sha256 == self.reference
                else "Huella distinta de la del informe"
            )
        self.fields["Comparación"].set(comparison)

    def current_report(self, client: ClientFile) -> dict:
        report = make_report(client, self.reference)
        if self.window_state is not None:
            report.update(self.window_state)
        if self.selected_profile is not None:
            profile, preferences = self.selected_profile
            settings = profile.summary()
            settings.pop("turn_execution_available")
            report["selected_profile"] = {
                "settings": settings,
                "execute_turns_preference": preferences.execute_turns,
            }
        return report

    def copy_state(self) -> None:
        self.analyze_window()
        if self.client is None or self.window_state is None:
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(
            json.dumps(self.current_report(self.client), indent=2, ensure_ascii=False)
        )
        self.status.set(f"Estado del PID {self.window_state['process']['pid']} copiado como JSON.")

    def export_report(self) -> None:
        if self.client is None:
            return
        filename = filedialog.asksaveasfilename(
            parent=self.root,
            title="Guardar informe del cliente",
            initialfile=f"panel-v2-cliente-{datetime.now():%Y%m%d-%H%M%S}.json",
            defaultextension=".json",
            filetypes=[("Informe JSON", "*.json")],
            confirmoverwrite=False,
        )
        if not filename:
            return
        try:
            save_report(self.current_report(self.client), Path(filename))
            self.status.set(f"Informe guardado en {filename}")
        except (DiagnosticError, OSError) as exc:
            self.status.set(str(exc))

    def show_profiles(self) -> None:
        try:
            open_saved_profiles(
                self.root, ProfileStore.for_windows(), on_select=self.select_profile
            )
        except (DiagnosticError, OSError) as exc:
            self.status.set(str(exc))

    def select_profile(
        self, name: str, profile: BotProfile, preferences: CharacterPreferences
    ) -> None:
        self.selected_profile = profile, preferences
        self.profile_label.set(f"{name} · Perfil {profile.number} elegido.")


def launch_panel_v2() -> None:
    system = WindowsSystem() if sys.platform == "win32" else None
    root = tk.Tk()
    PanelV2(root, system)
    root.mainloop()
