from collections.abc import Callable

from .character_profiles import CharacterPreferences, CharacterProfileStore
from .errors import DiagnosticError
from .profiles import ACTION_LABELS, TARGET_LABELS, BotProfile, ProfileStore, member_label


def open_saved_profiles(
    parent,
    templates: ProfileStore,
    *,
    on_select: Callable[[str, BotProfile, CharacterPreferences], None] | None = None,
) -> None:
    """Consult saved settings independently of the client connection."""
    import tkinter as tk
    from tkinter import ttk

    characters = CharacterProfileStore.saved_characters(templates)
    stores: list[tuple[str, ProfileStore]] = [
        (f"{store.name} · {store.key[0]}", store) for store in characters
    ]
    if on_select is not None:
        stores.append(("Perfiles generales", templates))
    if not stores:
        raise DiagnosticError("No encontré configuraciones de personajes guardadas en este equipo.")

    window = tk.Toplevel(parent)
    window.title("Perfiles guardados")
    window.minsize(765, 405)
    frame = ttk.Frame(window, padding=16)
    frame.pack(fill="both", expand=True)
    selection = ttk.Frame(frame)
    selection.pack(fill="x")
    ttk.Label(selection, text="Personaje").pack(side="left", padx=(0, 8))
    character_list = ttk.Combobox(
        selection,
        values=[label for label, _ in stores],
        state="readonly",
        width=43,
    )
    character_list.pack(side="left", fill="x", expand=True, padx=(0, 16))
    ttk.Label(selection, text="Perfil").pack(side="left", padx=(0, 8))
    profile_list = ttk.Combobox(selection, values=(1, 2, 3), state="readonly", width=4)
    profile_list.pack(side="left")

    columns = (
        ("slot", "Puesto", 105),
        ("name", "Nombre", 126),
        ("enabled", "Usar", 48),
        ("opening", "Primer turno", 125),
        ("later", "Después", 125),
        ("target", "Objetivo", 111),
    )
    table = ttk.Treeview(frame, columns=[key for key, _, _ in columns], show="headings", height=9)
    for key, label, width in columns:
        table.heading(key, text=label)
        table.column(key, width=width, minwidth=width, anchor="w")
    table.pack(fill="both", expand=True, pady=(12, 8))
    summary = ttk.Label(frame, style="Caption.TLabel", wraplength=710)
    summary.pack(anchor="w")
    window.bind("<Escape>", lambda _: window.destroy())

    def refresh(
        *, select_last_profile=False
    ) -> tuple[str, BotProfile, CharacterPreferences] | None:
        table.delete(*table.get_children())
        try:
            label, store = stores[character_list.current()]
            preferences = (
                store.load_preferences()
                if isinstance(store, CharacterProfileStore)
                else CharacterPreferences()
            )
            if select_last_profile:
                profile_list.current(preferences.selected_profile - 1)
            profile = store.load(int(profile_list.get()))
        except (DiagnosticError, OSError) as exc:
            summary.configure(text=str(exc))
            return
        for mercenary in profile.mercenaries:
            later = mercenary.action_for_turn(
                opening=False, first_only=profile.magic_first_turn_only
            )
            table.insert(
                "",
                "end",
                values=(
                    member_label(mercenary.slot),
                    mercenary.name,
                    "Sí" if mercenary.enabled else "No",
                    ACTION_LABELS[mercenary.action],
                    ACTION_LABELS[later],
                    TARGET_LABELS[mercenary.target] if mercenary.action in "QWERT" else "—",
                ),
            )
        turns = "activados" if preferences.execute_turns else "manuales"
        summary.configure(
            text=(
                f"Radio de búsqueda {profile.search_radius} casillas · "
                f"Espera antes de atacar {profile.attack_delay_seconds:g} s · "
                f"Turnos guardados {turns}"
            )
        )
        name = store.name if isinstance(store, CharacterProfileStore) else label
        return name, profile, preferences

    actions = ttk.Frame(frame)
    actions.pack(fill="x", pady=(8, 0))
    ttk.Button(actions, text="Cerrar", command=window.destroy).pack(side="right")
    if on_select is not None:
        select_profile = on_select

        def use_profile() -> None:
            selection = refresh()
            if selection is not None:
                select_profile(*selection)
                window.destroy()

        ttk.Button(actions, text="Usar perfil", command=use_profile).pack(side="right", padx=(0, 8))

    character_list.bind("<<ComboboxSelected>>", lambda _: refresh(select_last_profile=True))
    profile_list.bind("<<ComboboxSelected>>", lambda _: refresh())
    character_list.current(0)
    refresh(select_last_profile=True)
