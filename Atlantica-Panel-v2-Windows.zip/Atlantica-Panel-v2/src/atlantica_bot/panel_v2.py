"""Disk analysis and the independent entry point for Panel v2."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import struct
import sys
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Protocol

from .client_window import ClientWindow
from .errors import DiagnosticError
from .pe import MACHINES
from .report import Process, System, observe_module_header, save_report


@dataclass(frozen=True)
class ClientFile:
    name: str
    architecture: str
    bits: int
    sha256: str
    file_version: str | None
    size_bytes: int
    image_size: int
    sections: int


class WindowSystem(System, Protocol):
    def game_windows(self) -> list[ClientWindow]: ...

    def process_creation_time(self, pid: int) -> int: ...


def inspect_client_file(path: Path) -> ClientFile:
    try:
        import pefile
    except ModuleNotFoundError as exc:
        raise DiagnosticError(
            "Instala la dependencia con py -3 -m pip install -r requirements-panel-v2.txt."
        ) from exc

    data = path.read_bytes()
    try:
        with pefile.PE(data=data, fast_load=True) as pe_image:
            machine = pe_image.FILE_HEADER.Machine
            if machine not in MACHINES:
                raise DiagnosticError(f"Arquitectura PE 0x{machine:04x} sin soporte.")
            architecture, bits = MACHINES[machine]
            pe_image.parse_data_directories(
                directories=[pefile.DIRECTORY_ENTRY["IMAGE_DIRECTORY_ENTRY_RESOURCE"]]
            )
            version = next(iter(getattr(pe_image, "VS_FIXEDFILEINFO", ())), None)
            file_version = None
            if version is not None and version.Signature == 0xFEEF04BD:
                major_minor = version.FileVersionMS
                build_revision = version.FileVersionLS
                parts = (
                    major_minor >> 16,
                    major_minor & 0xFFFF,
                    build_revision >> 16,
                    build_revision & 0xFFFF,
                )
                file_version = ".".join(map(str, parts))
            return ClientFile(
                name=path.name,
                architecture=architecture,
                bits=bits,
                sha256=hashlib.sha256(data).hexdigest(),
                file_version=file_version,
                size_bytes=len(data),
                image_size=pe_image.OPTIONAL_HEADER.SizeOfImage,
                sections=pe_image.FILE_HEADER.NumberOfSections,
            )
    except pefile.PEFormatError as exc:
        raise DiagnosticError("El archivo no contiene un ejecutable PE válido.") from exc


def inspect_window(system: WindowSystem, selected: ClientWindow) -> tuple[ClientFile, dict]:
    def still_listed() -> bool:
        identity = selected.pid, selected.handle, selected.thread_id
        return any(
            (window.pid, window.handle, window.thread_id) == identity
            for window in system.game_windows()
        )

    started = system.process_creation_time(selected.pid)
    if not still_listed():
        raise DiagnosticError("La ventana seleccionada cambió. Actualiza la lista.")
    path = system.executable_path(selected.pid)
    if path.name.casefold() != "atlantica.exe":
        raise DiagnosticError("El PID elegido pertenece a otro ejecutable. Actualiza la lista.")
    client = inspect_client_file(path)
    if client.bits > struct.calcsize("P") * 8:
        raise DiagnosticError("Esta consulta requiere Python de 64 bits.")
    module = observe_module_header(system, Process(selected.pid, path.name))
    if (
        system.process_creation_time(selected.pid) != started
        or system.executable_path(selected.pid) != path
        or not still_listed()
    ):
        raise DiagnosticError("La instancia de Atlantica cambió durante la consulta.")
    module_size_matches = None
    if module["memory_read"]["status"] == "verified":
        module_size_matches = module["main_module"]["image_size"] == client.image_size
    return client, {
        "created_at": datetime.now(UTC).isoformat(),
        "process": {"pid": selected.pid, "name": path.name, "creation_time": started},
        "window": {"handle": selected.handle, "thread_id": selected.thread_id},
        **module,
        "image_size_matches_disk": module_size_matches,
        "game_mapping": "not_configured",
    }


def read_reference_sha256(path: Path) -> str:
    with path.open("rb") as handle:
        data = handle.read(65_537)
    try:
        if len(data) > 65_536:
            raise ValueError
        report = json.loads(data)
        digest = report["executable_on_disk"]["sha256"]
        if not isinstance(digest, str) or re.fullmatch(r"[0-9a-fA-F]{64}", digest) is None:
            raise ValueError
    except (KeyError, TypeError, ValueError) as exc:
        raise DiagnosticError("El informe de referencia debe contener un SHA-256 válido.") from exc
    return digest.lower()


def make_report(client: ClientFile, reference: str | None) -> dict:
    return {
        "schema_version": 1,
        "source": "panel_v2",
        "executable_on_disk": asdict(client),
        "comparison": (
            {"reference_sha256": reference, "match": client.sha256 == reference}
            if reference is not None
            else None
        ),
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Panel v2 de Atlantica Online.")
    parser.add_argument("--inspeccionar", type=Path, metavar="EXE")
    parser.add_argument("--comparar", type=Path, metavar="INFORME")
    parser.add_argument("--salida", type=Path, metavar="JSON")
    args = parser.parse_args(argv)
    try:
        if args.inspeccionar is not None:
            client = inspect_client_file(args.inspeccionar)
            reference = read_reference_sha256(args.comparar) if args.comparar else None
            report = make_report(client, reference)
            if args.salida:
                save_report(report, args.salida)
            else:
                print(json.dumps(report, indent=2, ensure_ascii=False))
        else:
            if args.comparar or args.salida:
                parser.error("--comparar y --salida requieren --inspeccionar.")
            from .panel_v2_view import launch_panel_v2

            launch_panel_v2()
    except (DiagnosticError, OSError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    return 0
