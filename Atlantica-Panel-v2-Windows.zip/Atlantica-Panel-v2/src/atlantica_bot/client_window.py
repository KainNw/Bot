from dataclasses import dataclass


@dataclass(frozen=True)
class ClientWindow:
    pid: int
    handle: int
    title: str
    thread_id: int | None = None

    @property
    def identity(self) -> tuple[int, int, int | None]:
        return self.pid, self.handle, self.thread_id

    @property
    def label(self) -> str:
        title = self.title.replace("\n", " ").replace("\r", " ")[:100]
        return f"PID {self.pid} · {title or 'Atlantica'} · ventana {self.handle:X}"
