"""Read the accessibility metadata Windows exposes for the selected game window."""

from __future__ import annotations

import json
import os
import subprocess
from datetime import UTC, datetime
from pathlib import Path

from .client_window import ClientWindow
from .errors import DiagnosticError
from .panel_v2 import WindowSystem, window_is_listed

CONTROL_LIMIT = 96

_INSPECT_CONTROLS = r"""
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes

$owner = [int]$env:ATLANTICA_PANEL_V2_PID
$handle = [IntPtr]::new([long]$env:ATLANTICA_PANEL_V2_HWND)
$limit = [int]$env:ATLANTICA_PANEL_V2_CONTROL_LIMIT
$root = [System.Windows.Automation.AutomationElement]::FromHandle($handle)
if ($null -eq $root -or $root.Current.ProcessId -ne $owner) {
    throw 'Window owner changed.'
}

$walker = [System.Windows.Automation.TreeWalker]::ControlViewWalker
$pending = [System.Collections.Generic.Queue[object]]::new()
$controls = [System.Collections.Generic.List[object]]::new()
$pending.Enqueue($root)
$visited = 0
$truncated = $false
while ($pending.Count -gt 0) {
    $element = $pending.Dequeue()
    $visited += 1
    $current = $element.Current
    if ($current.ProcessId -ne $owner) {
        continue
    }
    if ($visited -gt 1) {
        $id = [string]$current.AutomationId
        $controls.Add([pscustomobject]@{
            control_type = $current.ControlType.ProgrammaticName
            automation_id = $id.Substring(0, [Math]::Min($id.Length, 128))
            enabled = $current.IsEnabled
            offscreen = $current.IsOffscreen
            patterns = @($element.GetSupportedPatterns() | ForEach-Object { $_.ProgrammaticName })
        })
    }
    $child = $walker.GetFirstChild($element)
    while ($null -ne $child -and ($visited + $pending.Count) -lt $limit) {
        $pending.Enqueue($child)
        $child = $walker.GetNextSibling($child)
    }
    if ($null -ne $child) {
        $truncated = $true
    }
}
[pscustomobject]@{
    controls = $controls.ToArray()
    limit_reached = $truncated
} | ConvertTo-Json -Depth 5 -Compress
"""


def inspect_window_controls(system: WindowSystem, selected: ClientWindow) -> dict:
    created = system.process_creation_time(selected.pid)
    if not window_is_listed(system, selected):
        raise DiagnosticError("La ventana elegida cambió. Actualiza la lista.")
    system_root = os.environ.get("SystemRoot")
    if not system_root:
        raise DiagnosticError("La consulta de accesibilidad requiere Windows.")
    powershell = Path(system_root) / "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe"
    environment = {
        **os.environ,
        "ATLANTICA_PANEL_V2_PID": str(selected.pid),
        "ATLANTICA_PANEL_V2_HWND": str(selected.handle),
        "ATLANTICA_PANEL_V2_CONTROL_LIMIT": str(CONTROL_LIMIT),
    }
    try:
        result = subprocess.run(
            [
                str(powershell),
                "-NoLogo",
                "-NoProfile",
                "-NonInteractive",
                "-Command",
                _INSPECT_CONTROLS,
            ],
            capture_output=True,
            encoding="utf-8-sig",
            errors="replace",
            env=environment,
            timeout=8,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise DiagnosticError("La consulta de accesibilidad agotó su tiempo de espera.") from exc
    except OSError as exc:
        raise DiagnosticError("Windows PowerShell no está disponible para la consulta.") from exc
    if result.returncode != 0:
        raise DiagnosticError("Windows no pudo consultar los controles de esa ventana.")
    try:
        report = json.loads(result.stdout)
        if (
            not isinstance(report["controls"], list)
            or len(report["controls"]) >= CONTROL_LIMIT
            or type(report["limit_reached"]) is not bool
        ):
            raise ValueError
    except (KeyError, TypeError, ValueError) as exc:
        raise DiagnosticError("Windows devolvió un informe de accesibilidad inválido.") from exc
    if system.process_creation_time(selected.pid) != created or not window_is_listed(
        system, selected
    ):
        raise DiagnosticError("La instancia cambió durante la consulta de accesibilidad.")
    return {
        "schema_version": 1,
        "source": "windows_ui_automation",
        "created_at": datetime.now(UTC).isoformat(),
        "process": {"pid": selected.pid, "creation_time": created},
        "window": {"handle": selected.handle, "thread_id": selected.thread_id},
        "controls": report["controls"],
        "limit_reached": report["limit_reached"],
    }
